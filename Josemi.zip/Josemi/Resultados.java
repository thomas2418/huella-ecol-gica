import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Resultados extends JPanel implements ActionListener{
    private JButton resultados;
    private JLabel titulo11;
    private JTextArea campodatos;
    private JButton ver;
    private JLabel titulo12;
    private JTextArea resultadosm;
    private static String temperatura1;
    private static String humedad1;
    private static String ph1;
    private static String lluvia1;

    public Resultados(String temperatura1, String humedad1, String lluvia1, String ph1) {
        //construct components
        resultados = new JButton ("Ver resultados");
        titulo11 = new JLabel ("Tus datos");
        campodatos = new JTextArea (5, 5);
        ver = new JButton ("Ver");
        titulo12 = new JLabel ("Los resultados de tu terreno son:");
        resultadosm = new JTextArea (5, 5);
        this.temperatura1 = temperatura1;
        this.humedad1 = humedad1;
        this.lluvia1 = lluvia1;
        this.ph1 = ph1;
        resultados.addActionListener(this);
        ver.addActionListener(this);

        //adjust size and set layout
        setPreferredSize (new Dimension (507, 283));
        setLayout (null);

        //add components
        add (resultados);
        add (titulo11);
        add (campodatos);
        add (ver);
        add (titulo12);
        add (resultadosm);

        //set component bounds (only needed by Absolute Positioning)
        resultados.setBounds (235, 220, 130, 35);
        titulo11.setBounds (30, 20, 100, 25);
        campodatos.setBounds (10, 50, 100, 95);
        ver.setBounds (20, 160, 75, 25);
        titulo12.setBounds (160, 15, 195, 35);
        resultadosm.setBounds (140, 50, 320, 155);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new Resultados(temperatura1, lluvia1,humedad1,ph1));
        frame.pack();
        frame.setVisible (true);
    }


    
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== ver){
        String textdef = "ph =" + ph1 +"\n Humedad ="+ humedad1 + "\n Lluvia ="+ lluvia1+ "\n Temperatura ="+ temperatura1;
        campodatos.setText(textdef);
        }
        if (e.getSource()==resultados){
            int temperatura2 = Integer.parseInt(temperatura1);
            int humedad2 = Integer.parseInt(humedad1);
            Double ph2= Double.parseDouble(ph1);
            int lluvia2 =Integer.parseInt(lluvia1);

            String textodeff;

            if (temperatura2 > 30 && humedad2  < 50 && ph2 < 6 && lluvia2 < 100) {
          String texto1 = "El suelo está caliente, seco y esta bajo en pH.\n Se recomienda un riego abundante.";
          textodeff = texto1;
        }else if(temperatura2 < 15 && humedad2 > 70 && ph2 > 6.5 && lluvia2 > 100){
            String texto2 = "El suelo está frío, húmedo y esta alto en pH.\n Se recomienda reducir el riego.";
            textodeff = texto2;
        }else{
            String texto3 ="El suelo tiene condiciones aceptables para el cultivo.";
            textodeff = texto3;
        }
        resultadosm.setText(textodeff);
    }
}
}