import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Iniciosesion extends JPanel implements ActionListener{
    private JButton siguiente;
    private JLabel us;
    private JLabel cont;
    private JTextField Usuario2;
    private JTextField Contraseña2;
    private JLabel titulo5;
    private static String contraseña;
    private static String usuario1;

    public Iniciosesion(String contraseña, String usuario1) {
        //construct components
        siguiente = new JButton ("Ingresar");
        us = new JLabel ("Usuario");
        cont = new JLabel ("Contraseña");
        Usuario2 = new JTextField (5);
        Contraseña2 = new JTextField (5);
        titulo5 = new JLabel ("Inicio Sesion");
        this.contraseña=contraseña;
        this.usuario1 = usuario1;
        siguiente.addActionListener(this);

        //adjust size and set layout
        setPreferredSize (new Dimension (516, 274));
        setLayout (null);

        //add components
        add (siguiente);
        add (us);
        add (cont);
        add (Usuario2);
        add (Contraseña2);
        add (titulo5);

        //set component bounds (only needed by Absolute Positioning)
        siguiente.setBounds (210, 195, 105, 35);
        us.setBounds (150, 85, 100, 25);
        cont.setBounds (320, 85, 100, 25);
        Usuario2.setBounds (125, 105, 100, 25);
        Contraseña2.setBounds (305, 105, 100, 25);
        titulo5.setBounds (230, 40, 100, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new Iniciosesion(usuario1, contraseña));
        frame.pack();
        frame.setVisible (true);
    }


    
    public void actionPerformed(ActionEvent e) {
        String usuario2 = Usuario2.getText();
        String contraseña2 = Contraseña2.getText();
        if (contraseña2.equals(contraseña)&& usuario2.equals(usuario1)){
            if(e.getSource()==siguiente){
                JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
                currentFrame.dispose();

            JFrame frame = new JFrame ("MyPanel");
            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add (new Ingresardatos());
            frame.pack();
             frame.setVisible (true);
            }
        }

    }
}
