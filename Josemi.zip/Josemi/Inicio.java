import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Inicio extends JPanel implements ActionListener {
    private JButton sig;
    private JLabel Titulo1;
    private JLabel titulo2;
    private JLabel titulo3;
    private JTextField usuario;
    private JTextField nombre;
    private JLabel nom;
    private JLabel us;
    private JLabel cont;
    private JTextField contraseña1;

    public Inicio() {
        //construct components
        sig = new JButton ("Siguiente");
        Titulo1 = new JLabel ("Bienvenido a...");
        titulo2 = new JLabel ("Agro Tester");
        titulo3 = new JLabel ("Ingresa tus datos:");
        usuario = new JTextField (5);
        nombre = new JTextField (5);
        nom = new JLabel ("Nombre");
        us = new JLabel ("Usuario");
        cont = new JLabel ("Crear Contraseña");
        contraseña1 = new JTextField (5);
        sig.addActionListener(this);

        //adjust size and set layout
        setPreferredSize (new Dimension (544, 296));
        setLayout (null);

        //add components
        add (sig);
        add (Titulo1);
        add (titulo2);
        add (titulo3);
        add (usuario);
        add (nombre);
        add (nom);
        add (us);
        add (cont);
        add (contraseña1);

        //set component bounds (only needed by Absolute Positioning)
        sig.setBounds (215, 190, 110, 35);
        Titulo1.setBounds (230, 5, 95, 25);
        titulo2.setBounds (235, 30, 100, 25);
        titulo3.setBounds (20, 70, 115, 25);
        usuario.setBounds (220, 125, 100, 25);
        nombre.setBounds (55, 125, 100, 25);
        nom.setBounds (80, 100, 100, 25);
        us.setBounds (245, 100, 100, 25);
        cont.setBounds (385, 100, 110, 25);
        contraseña1.setBounds (385, 125, 100, 25);
    }


    public static void main (String[] args) {
        JFrame frame = new JFrame ("MyPanel");
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add (new Inicio());
        frame.pack();
        frame.setVisible (true);
    }


  
    public void actionPerformed(ActionEvent e) {
       String nombre1 = nombre.getText(); 
       String usuario1 = usuario.getText();
       String contraseña = contraseña1.getText();

       if(e.getSource()== sig){
        JFrame currentFrame = (JFrame) SwingUtilities.getWindowAncestor(this);
            currentFrame.dispose();

            JFrame frame = new JFrame ("MyPanel");
            frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add (new Iniciosesion(contraseña,usuario1));
            frame.pack();
             frame.setVisible (true);

       }

    }
}